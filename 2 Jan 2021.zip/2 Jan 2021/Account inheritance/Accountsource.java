
	class Account
	{
		String name;
		int day;
		int month;
		int year;

	
		Account()
		{
			this.name="Not Given";
			this.day=12;
			this.month=05;
			this.year=2020;
		}	
		Account(String name,int d,int m,int y)
		{

			this.name=name;
			this.day=d;
			this.month=m;
			this.year=y;
		}
		void setName(String name)
		{
			this.name=name;
		}
		String getName()	
		{
			return name;
		}
		void setDay(int d)
		{
			this.day=d;
		}
		int getDay()
		{
			return day;
		}
		void setMonth(int m)
		{
			this.month=m;
		}
		int getMonth()
		{
			return month;
		}
		void setYear(int y)
		{
			this.year=y;
		}
		int getYear()
		{
			return year;
		}
		void display()
		{
			System.out.println("Name of Account Holder :"+name);
			System.out.println("Date of Account opening :"+day+"/"+month+"/"+year);	
			
		}

	}//Account class ends here

	class Bank extends Account
	{
		int acc;
		String type;
		double balance;
		double interest;

		public Bank()
		{
			super();
			this.acc=223567890;
			this.type="Not Given";
			this.balance=50000;
			this.interest=7.5;
		}
		Bank(String name,int d,int m,int y,int a,String t,double b,double i)
		{
			super(name,d,m,y);
			this.acc=a;
			this.type=t;
			this.balance=b;
			this.interest=i;
		}
		void setAcc(int a)
    		{
     		   	this.acc=a;
    		}
    		int getAcc()
    		{
        		return acc;
		}   
 		void setType(String t)
    		{
        		this.type=t;
    		}
    		String getType()
    		{
        		return type;
    		}
    		void setBalance(double b)
   		{
        		this.balance=b;
    		}
    		double getBalance()
    		{
        		return balance;
    		}
    		void setInterest(double i)
    		{
        		this.interest=i;
    		}
    		double getInterest()
    		{
        		return interest;
    		}
		void display()
		{
			super.display();
			System.out.println("Account Number :"+acc);
			System.out.println("Account Type :"+type);
			System.out.println("Account Balance :"+balance);
			System.out.println("Account Interest :"+interest);
		}
		
	}//Bank class ends here

	class SocialMedia extends Account
	{
		String type;
		String username;
		int password;

		public SocialMedia()
		{
			this.type="instagram";
			this.username="Suraj";
			this.password=12202056;	
		}
		SocialMedia(String name,int d,int m,int y,String t,String u,int p)
		{
			super(name,d,m,y);
			this.type=t;
			this.username=u;
			this.password=p;
		}
		void setType(String t)
		{
			this.type=t;
		}
		String getType()
		{
			return type;
		}
		void setUsername(String u)
		{
			this.username=u;
		}
		String getUsername()
		{
			return username;
		}
		void setPassword(int p)
		{
			this.password=p;
		}
		void display()
		{
			super.display();
			System.out.println("Account on :"+type);
			System.out.println("Username :"+username);
			System.out.println("Password :"+password);
		}
		
	}

	class Accounttest
	{
		public static void main(String args[])
	     {
		Account a1;
		a1=new Account("Sanket",22,4,2021);
		a1.display();
		System.out.println();

		Bank b1;
		b1=new Bank("Mangesh",2,6,2020,34567890,"saving",500000,8);
		b1.display();
		
		System.out.println();

		
		SocialMedia s1;
		s1=new SocialMedia("Shailesh",3,6,2021,"Instagram","Shailesh123",23456789);
		s1.display();

            }
	}

	