	class Employee
	{
		int id;
		String name;
		double sal;
		Employee()
		{
			this.id=102;
			this.name="Not Given";
			this.sal=10000;
		}

		Employee(int id,String name, double sal)
		{
			this.id=id;
			this.name=name;
			this.sal=sal;
		}
		void setId(int id)
		{
			this.id=id;
		}
		int getId()
		{
			return id;
		}
		void setName(String name)
		{
			this.name=name;
		}
		String getName()
		{
			return name;
		}
		void setSal(double sal)
		{
			this.sal=sal;
		}
		double getSal()
		{
			return sal;
		}
		void display()
		{

			System.out.println("Id is :"+id);
			System.out.println("Name is :"+ name);
			System.out.println("Salary is :"+sal);

		}
	}//class Employee ends here

	class SalesManager extends Employee
	{
		int target;
		double incentives;
		
		public SalesManager()
		{
			super();
			this.target=22;
			this.incentives=150000;	
		}
		SalesManager(int id,String name, double sal,int target,double incentives)
		{
			super(id,name,sal);
			this.target=target;
			this.incentives=incentives;
		}
		void setTarget(int target)
		{
			this.target=target;
		}
		int getTarget()
		{
			return target;
		}
		void setIncentives(double incentives)
		{
			this.incentives=incentives;
		}
		double getIncentives()
		{
			return incentives;
		}
		void display()
		{
			super.display();
			System.out.println("Target is :"+target);
			System.out.println("Incentives is:"+incentives);
		}
		
	}//class SalesManager ends here

	class Admin extends Employee
	{
		double allowance;

		Admin()
		{
			super();
			allowance=44;
		}

		Admin(int id,String name, double sal,double allowance)
		{
			super(id,name,sal);
			this.allowance=allowance;
		}
		void setAllowance(double allowance)
		{
			this.allowance=allowance;
		}	
		double getAllowance()
		{
			return allowance;
		}
		void display()
		{
			super.display();
			System.out.println("Allowance is :"+allowance);
		}
	}//Admin class ends here

	class Demoinheritance
	{
		public static void main(String args[])
		{
			Employee E1;
			E1=new Employee(103,"Shubham",400000);
			E1.display();

			System.out.println();

	  		SalesManager S1;
			S1=new SalesManager(104,"Vaibhav",50000,30,25000);
			S1.display();
			
			System.out.println();

			Admin A1;
			A1=new Admin(105,"Akshay",60000,70);
			A1.display();
		}
	}